#define UNIX

#ifdef UNIX

#include <fstream>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cstdlib> 
#include <ctime>
#include <assert.h>

#else

#include <fstream>
#include <string>
#include <iostream>
#include <math.h>
#include <stdlib.h> 
#include <time.h>
#include <assert.h>

#endif


using namespace std;

/************************************************************************/
/* Separate genes from gtf files */
/************************************************************************/

bool strand_positive = true; //true for positive strand

const long MAX_CHR_LENGTH = 1000000000;
const long MAX = 2000000000;
const int DIFF_SAMPLE_CNT = 2;

class transcript;

class parentTranscript
{
public:
	transcript *parent;
	parentTranscript *next;

	parentTranscript();
};


class exon
{
public:
	char name[100];
	int strand;
	long start;
	long end;

	double truth_prop[DIFF_SAMPLE_CNT];
	double truth_cnt[DIFF_SAMPLE_CNT];
	double data_prop[DIFF_SAMPLE_CNT];
	double data_cnt[DIFF_SAMPLE_CNT];

	parentTranscript *parents;
	exon *next;

	exon();
};

class junction
{
public:
	long start;
	long end;

	double truth_prop[DIFF_SAMPLE_CNT];
	double truth_cnt[DIFF_SAMPLE_CNT];
	double data_prop[DIFF_SAMPLE_CNT];
	double data_cnt[DIFF_SAMPLE_CNT];

	parentTranscript *parents;
	junction *next;

	junction();
};

class transcript
{
public:
	char transID[100];
	int strand;
	long start;
	long end;
	double truth_prop[DIFF_SAMPLE_CNT];
	double truth_cnt[DIFF_SAMPLE_CNT];
	double data_prop[DIFF_SAMPLE_CNT];
	double data_cnt[DIFF_SAMPLE_CNT];

	long exon_cnt;
	long junction_cnt;

	exon *exonList;
	junction *junctionList;
	transcript *next;

	transcript();
};

class gene
{
public:
	char geneID[100];
	char chrNm[100];
	int strand;
	long start;
	long end;
	long length;

	long exon_cnt;
	long junction_cnt;
	long trans_cnt;

	double data_prop_gene[DIFF_SAMPLE_CNT];
	double data_cnt_gene[DIFF_SAMPLE_CNT];

	exon *exonList;
	junction *junctionList;
	transcript *transList;

	gene();
};

class geneExonBoundary
{
public:
	long position;
	geneExonBoundary *next;

	geneExonBoundary();
};


const long MAXTRANSNUM = 10000000;

transcript* transList_posStrand[MAXTRANSNUM];
long transListNum_posStrand = 0;
gene* geneList_posStrand[MAXTRANSNUM / 10];
long geneListNum_posStrand = 0;

transcript* transList_negStrand[MAXTRANSNUM];
long transListNum_negStrand = 0;
gene* geneList_negStrand[MAXTRANSNUM / 10];
long geneListNum_negStrand = 0;

char dirPrefix[400];
char chr_name[100];


double mergeSort_Larray[MAXTRANSNUM / 2];
double mergeSort_Rarray[MAXTRANSNUM / 2];
void* mergeSort_LorderedList[MAXTRANSNUM / 2];
void* mergeSort_RorderedList[MAXTRANSNUM / 2];
double sortKey[MAXTRANSNUM]; 
void* sortList[MAXTRANSNUM];

long CHROMOSOME_START = MAX_CHR_LENGTH;
long CHROMOSOME_END   = 0;

parentTranscript::parentTranscript()
{
	parent = NULL;
	next = NULL;
}

exon::exon()
{
	for (int i = 0; i < 100; i++)
	{
		name[i] = '\0';
	}
	strand = 1;
	start = 0;
	end = 0;

	for (int i = 0; i < DIFF_SAMPLE_CNT; i++)
	{
		truth_prop[i] = 0.0;
		truth_cnt[i] = 0.0;
		data_prop[i] = 0.0;
		data_cnt[i] = 0.0;
	}

	parents = NULL;
	next = NULL;
}

junction::junction()
{
	start = 0;
	end = 0;

	for (int i = 0; i < DIFF_SAMPLE_CNT; i++)
	{
		truth_prop[i] = 0.0;
		truth_cnt[i] = 0.0;
		data_prop[i] = 0.0;
		data_cnt[i] = 0.0;
	}

	parents = NULL;
	next = NULL;
}

transcript::transcript()
{
	for (int i = 0; i < 100; i++)
	{
		transID[i] = '\0';
	}
	strand = 1;
	start = MAX;
	end = 0;

	for (int i = 0; i < DIFF_SAMPLE_CNT; i++)
	{
		truth_prop[i] = 0.0;
		truth_cnt[i] = 0.0;
		data_prop[i] = 0.0;
		data_cnt[i] = 0.0;
	}

	exon_cnt = 0;
	junction_cnt = 0;

	exonList = NULL;
	junctionList = NULL;
	next = NULL;
}

gene::gene()
{
	for (int i = 0; i < 100; i++)
	{
		geneID[i] = '\0';
		chrNm[i] = '\0';
	}
	strand = 1;
	start = MAX;
	end = 0;
	length = 0;

	exon_cnt = 0;
	junction_cnt = 0;
	trans_cnt = 0;

	for (int i = 0; i < DIFF_SAMPLE_CNT; i++)
	{
		data_prop_gene[i] = 0.0;
		data_cnt_gene[i] = 0.0;
	}

	exonList = NULL;
	junctionList = NULL;
	transList = NULL;
}


geneExonBoundary::geneExonBoundary()
{
	position = 0;
	next = NULL;
}


void merge(long p, long q, long r)
{
	long n1, n2, i, j, k;

	n1 = q - p + 1;
	n2 = r - q;

	for (i = 1; i <= n1; i++)
	{
		mergeSort_Larray[i] = sortKey[p + i - 1];
		mergeSort_LorderedList[i] = sortList[p + i - 1];
	}
	for (j = 1; j <= n2; j++)
	{
		mergeSort_Rarray[j] = sortKey[q + j];
		mergeSort_RorderedList[j] = sortList[q + j];
	}

	mergeSort_Larray[n1 + 1] = MAX_CHR_LENGTH * 2;
	mergeSort_Rarray[n2 + 1] = MAX_CHR_LENGTH * 2;

	i = 1;
	j = 1;

	for (k = p; k <= r; k++)
	{
		if (mergeSort_Larray[i] <= mergeSort_Rarray[j])
		{
			sortKey[k] = mergeSort_Larray[i];
			sortList[k] = mergeSort_LorderedList[i];

			i++;
		} 
		else
		{
			sortKey[k] = mergeSort_Rarray[j];
			sortList[k] = mergeSort_RorderedList[j];

			j++;
		}
	}

	return;
}


void mergeSort(long sortList_size)
{
	//non-recursive merge sort for sorting junctions
	long m, n, i, r;
	m = 1;
	n = sortList_size;

	while (m <= n)
	{
		i = 1;
		while (i <= n - m)
		{
			r = (i + 2 * m - 1) < n ? (i + 2 * m - 1) : n;
			merge(i, i + m - 1, r);
			i = i + 2 * m;
		}

		m = m * 2;
	}

	return;
}



void getTranscriptsFromGTF(char* inputfilename)
	//this is for GTF format!!
{
	ifstream inputfile;
	inputfile.open(inputfilename);

	char chrNm[100], lineCategory[100], strand[5], geneID[300], transID[300], tmpChar[100];
	int tmp;
	long start, end, iLoop;
	string otherInfo;
	transcript *curTrans;
	exon *newExon;

	for (tmp = 0; tmp < 100; tmp++)
	{
		chrNm[tmp] = '\0';
	}

	inputfile >> chrNm;
	while (chrNm[0] != '\0')
	{
		inputfile >> tmpChar;
		inputfile >> lineCategory;
		inputfile >> start;
		inputfile >> end;
		inputfile >> tmpChar;
		inputfile >> strand;
		inputfile >> tmpChar;
		inputfile >> tmpChar;
		inputfile >> geneID;
		inputfile >> tmpChar;
		inputfile >> transID;
		getline(inputfile, otherInfo);

		if (strcmp(lineCategory, "exon") == 0)
		{
			for (tmp = 0; geneID[tmp+1] != '\"'; tmp++)
			{
				geneID[tmp] = geneID[tmp+1];
			}
			geneID[tmp] = '\0';

			for (tmp = 0; transID[tmp+1] != '\"'; tmp++)
			{
				transID[tmp] = transID[tmp+1];
			}
			transID[tmp] = '\0';


			//make a new exon for the transcript
			newExon = new exon;

			if (strcmp(strand, "+") == 0)
			{
				for (iLoop = transListNum_posStrand; iLoop >= 1; iLoop--)
				{
					curTrans = transList_posStrand[iLoop];
					if (strcmp(transID, curTrans->transID) == 0)
					{
						break;
					}
				}

				if (iLoop < 1)
				{
					//build a new transcript
					curTrans = new transcript;
					transList_posStrand[++transListNum_posStrand] = curTrans;
				}

				newExon->strand = 1;
			} 
			else if (strcmp(strand, "-") == 0)
			{
				for (iLoop = transListNum_negStrand; iLoop >= 1; iLoop--)
				{
					curTrans = transList_negStrand[iLoop];
					if (strcmp(transID, curTrans->transID) == 0)
					{
						break;
					}
				}

				if (iLoop < 1)
				{
					//build a new transcript
					curTrans = new transcript;
					transList_negStrand[++transListNum_negStrand] = curTrans;
				}

				newExon->strand = 0;
			}
			else
			{
				cout << "Error: unrecognized strand. Please confirm... ";
				cin >> tmpChar;
				exit(1);
			}

			newExon->start = start;
			newExon->end = end;

			newExon->next = curTrans->exonList;
			curTrans->exonList = newExon;

			strcpy(curTrans->transID, transID);
			curTrans->strand = newExon->strand;
			if (start < curTrans->start)
			{
				curTrans->start = start;
			}
			if (end	> curTrans->end)
			{
				curTrans->end = end;
			}
		}
		else
		{
			//do nothing
		}

		chrNm[0] = '\0';
		inputfile >> chrNm;		
	}

	inputfile.close();

	return;
}

void buildGeneList_posStrand()
{
	//build geneList from transcript list, based on overlapping
	long iLoop;

	//sort the transcripts 
	for (iLoop = 1; iLoop <= transListNum_posStrand; iLoop++)
	{
		sortKey[iLoop] = double(transList_posStrand[iLoop]->end);
		sortList[iLoop] = (void*)(transList_posStrand[iLoop]);
	}
	mergeSort(transListNum_posStrand);

	for (iLoop = 1; iLoop <= transListNum_posStrand; iLoop++)
	{
		sortKey[iLoop] = double(((transcript*)(sortList[iLoop]))->start);
	}
	mergeSort(transListNum_posStrand);

	for (iLoop = 1; iLoop <= transListNum_posStrand; iLoop++)
	{
		transList_posStrand[iLoop] = (transcript*)(sortList[iLoop]);
	}


	//build gene list
	gene *newGene = NULL;
	transcript *curTrans;
	long curStart, curEnd = 0;
	int curStrand;

	for (iLoop = 1; iLoop <= transListNum_posStrand; iLoop++)
	{
		curTrans = transList_posStrand[iLoop];

		if (curTrans->start <= curEnd)
		{
			//same gene

			curTrans->next = newGene->transList;
			newGene->transList = curTrans;
			newGene->trans_cnt += 1;

			curStart = curTrans->start < curStart ? curTrans->start : curStart;
			curEnd   = curTrans->end   > curEnd   ? curTrans->end   : curEnd;
		}
		else
		{
			//different gene
			//conclude the last gene
			if (newGene != NULL)
			{
				newGene->start = curStart;
				newGene->end   = curEnd;
				sprintf(newGene->geneID, "%s:%ld-%ldW", chr_name, curStart, curEnd);

				geneList_posStrand[++geneListNum_posStrand] = newGene;
			}

			//make a new gene
			newGene = new gene;
			newGene->strand = 1;
			strcpy(newGene->chrNm, chr_name);

			curTrans->next = newGene->transList;
			newGene->transList = curTrans;
			newGene->trans_cnt += 1;

			curStart = curTrans->start;
			curEnd   = curTrans->end;
		}
	}
	//conclude the last gene
	if (newGene != NULL)
	{
		newGene->start = curStart;
		newGene->end   = curEnd;
		sprintf(newGene->geneID, "%s:%ld-%ldW", chr_name, curStart, curEnd);

		geneList_posStrand[++geneListNum_posStrand] = newGene;
	}

	return;
}


void buildGeneList_negStrand()
{
	//build geneList from transcript list, based on overlapping
	long iLoop;

	//sort the transcripts 
	for (iLoop = 1; iLoop <= transListNum_negStrand; iLoop++)
	{
		sortKey[iLoop] = double(transList_negStrand[iLoop]->end);
		sortList[iLoop] = (void*)(transList_negStrand[iLoop]);
	}
	mergeSort(transListNum_negStrand);

	for (iLoop = 1; iLoop <= transListNum_negStrand; iLoop++)
	{
		sortKey[iLoop] = double(((transcript*)(sortList[iLoop]))->start);
	}
	mergeSort(transListNum_negStrand);

	for (iLoop = 1; iLoop <= transListNum_negStrand; iLoop++)
	{
		transList_negStrand[iLoop] = (transcript*)(sortList[iLoop]);
	}


	//build gene list
	gene *newGene = NULL;
	transcript *curTrans;
	long curStart, curEnd = 0;
	int curStrand;

	for (iLoop = 1; iLoop <= transListNum_negStrand; iLoop++)
	{
		curTrans = transList_negStrand[iLoop];

		if (curTrans->start <= curEnd)
		{
			//same gene

			curTrans->next = newGene->transList;
			newGene->transList = curTrans;
			newGene->trans_cnt += 1;

			curStart = curTrans->start < curStart ? curTrans->start : curStart;
			curEnd   = curTrans->end   > curEnd   ? curTrans->end   : curEnd;
		}
		else
		{
			//different gene
			//conclude the last gene
			if (newGene != NULL)
			{
				newGene->start = curStart;
				newGene->end   = curEnd;
				sprintf(newGene->geneID, "%s:%ld-%ldC", chr_name, curStart, curEnd);

				geneList_negStrand[++geneListNum_negStrand] = newGene;
			}

			//make a new gene
			newGene = new gene;
			newGene->strand = 0;
			strcpy(newGene->chrNm, chr_name);

			curTrans->next = newGene->transList;
			newGene->transList = curTrans;
			newGene->trans_cnt += 1;

			curStart = curTrans->start;
			curEnd   = curTrans->end;
		}
	}
	//conclude the last gene
	if (newGene != NULL)
	{
		newGene->start = curStart;
		newGene->end   = curEnd;
		sprintf(newGene->geneID, "%s:%ld-%ldC", chr_name, curStart, curEnd);

		geneList_negStrand[++geneListNum_negStrand] = newGene;
	}

	return;
}

void Output(char *inputfilename, char *outputfile_path, char *chromosome)
{
	long iLoop;
	char outputfilename[2000];
	char geneNames[2000];	

	char chrNm[100], lineCategory[100], tmpChar[100];
	long start, end;
	string otherInfo;
	int tmp;

	ofstream outputfile;
	ofstream outputfile_geneName;
	ifstream inputfile;

	char comd[5000];
	sprintf(comd, "mkdir %s%sW", outputfile_path, chromosome);
	system(comd);
	sprintf(comd, "mkdir %s%sC", outputfile_path, chromosome);
	system(comd);
	
	for (iLoop = 1; iLoop <= geneListNum_posStrand; iLoop++)
	{
		sprintf(geneNames, "%s%sW/GeneName.txt", outputfile_path, chromosome);
		outputfile_geneName.open(geneNames);
		outputfile_geneName << geneList_posStrand[iLoop]->start << "-" << geneList_posStrand[iLoop]->end << "W" << endl;
		sprintf(outputfilename, "%s%s/%ld-%ldW", outputfile_path, chromosome, geneList_posStrand[iLoop]->start, geneList_posStrand[iLoop]->end);
		outputfile.open(outputfilename);

		inputfile.open(inputfilename);
		for (tmp = 0; tmp < 100; tmp++)
		{
			chrNm[tmp] = '\0';
		}

		inputfile >> chrNm;
		while (chrNm[0] != '\0')
		{
			inputfile >> tmpChar;
			inputfile >> lineCategory;
			inputfile >> start;
			inputfile >> end;
			getline(inputfile, otherInfo);

			if (start >= geneList_posStrand[iLoop]->start && end <= geneList_posStrand[iLoop]->end)
			{
				outputfile << chrNm << '\t' << tmpChar << '\t' << lineCategory << '\t' << start << '\t' << end << otherInfo << endl;
			}

			chrNm[0] = '\0';
			inputfile >> chrNm;

		}
		inputfile.close();
		outputfile.close();

		outputfile_geneName.close();
	}

	for (iLoop = 1; iLoop <= geneListNum_negStrand; iLoop++)
	{
		sprintf(geneNames, "%s%sC/GeneName.txt", outputfile_path, chromosome);
		outputfile_geneName.open(geneNames);
		outputfile_geneName << geneList_negStrand[iLoop]->start << "-" << geneList_negStrand[iLoop]->end << "C" << endl;
		sprintf(outputfilename, "%s%s/%ld-%ldC", outputfile_path, chromosome, geneList_negStrand[iLoop]->start, geneList_negStrand[iLoop]->end);
		outputfile.open(outputfilename);

		inputfile.open(inputfilename);
		for (tmp = 0; tmp < 100; tmp++)
		{
			chrNm[tmp] = '\0';
		}

		inputfile >> chrNm;
		while (chrNm[0] != '\0')
		{
			inputfile >> tmpChar;
			inputfile >> lineCategory;
			inputfile >> start;
			inputfile >> end;
			getline(inputfile, otherInfo);

			if (start >= geneList_negStrand[iLoop]->start && end <= geneList_negStrand[iLoop]->end)
			{
				outputfile << chrNm << '\t' << tmpChar << '\t' << lineCategory << '\t' << start << '\t' << end << otherInfo << endl;
			}

			chrNm[0] = '\0';
			inputfile >> chrNm;

		}
		inputfile.close();
		outputfile.close();
		outputfile_geneName.close();
	}

	return;
}


int main(int argc, char* argv[])
{
	if (argc != 4)
	{
		cout << argv[0] << "\t<inputfilename_gtf>" << "\t<outputfile_path>" << "\t<ChromosomeName>" << endl;
		return 1;
	}

	strcpy(chr_name, argv[3]);
	getTranscriptsFromGTF(argv[1]);
	buildGeneList_posStrand();
	buildGeneList_negStrand();
	Output(argv[1], argv[2], argv[3]);

	return 0;
}
