#define UNIX

#ifdef UNIX

#include <fstream>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cstdlib> 
#include <ctime>
#include <assert.h>
#include <algorithm>

#else

#include <fstream>
#include <string>
#include <iostream>
#include <math.h>
#include <stdlib.h> 
#include <time.h>
#include <assert.h>
#include <algorithm>

#endif


using namespace std;


/************************************************************************/
/* Separate GTF file by chromosome */
/************************************************************************/

// Input a GTF file, separate it by chromsome names
void Parse(char *inputfilename, char *outputfile_path)
{
	ifstream inputfile;
	inputfile.open(inputfilename);
	fstream outputfile_gtf;
	ofstream outputfile;
	
	char chromsome[100], outputfilename_gtf[1000], outputfilename[1000], chrName[100][100];
	string info;
	int tmp, iLoop, chrNm;
	bool found;
	
	chrNm = 0;
	for (tmp = 0; tmp < 100; tmp++)
	{
		chromsome[tmp] = '\0';
		for (iLoop = 0; iLoop < 100; iLoop++)
		{
			chrName[tmp][iLoop] = '\0';
		}
	}
	inputfile >> chromsome;
	while(chromsome[0] != '\0')
	{
		getline(inputfile, info);
		
		// Separate GTF file by its chromosome
		sprintf(outputfilename_gtf, "%s%s.gtf", outputfile_path, chromsome);
		outputfile_gtf.open (outputfilename_gtf, fstream::in | fstream::out | fstream::app);
		outputfile_gtf << chromsome << info << endl;
		outputfile_gtf.close();

		found = false;
		for (tmp = 1; tmp <= chrNm; tmp++)
		{
			if (strcmp(chrName[tmp], chromsome) == 0)
			{
				found = true;
				break;
			}
		}
		if (found == false)
		{
			chrNm++;
			strcpy(chrName[chrNm], chromsome);
		}
		chromsome[0] = '\0';
		inputfile >> chromsome;
	}

	sprintf(outputfilename, "%sChromosomeName.txt", outputfile_path);
	outputfile.open(outputfilename);
	for (tmp = 1; tmp <= chrNm; tmp++)
	{
		outputfile << chrName[tmp] << endl;
	}

	inputfile.close();
	outputfile.close();
	return;
}

int main(int argc, char* argv[])
{
	if (argc != 3)
	{
		cout << argv[0] << "\t<gtfFile>" << "\t<Output_Path>" << endl;
		return 1;
	}
	Parse(argv[1], argv[2]);
	return 0;
}