#include "SpliceGraph.h"

parentTranscript::parentTranscript()
{
	parent = NULL;
	next = NULL;
}

Exon::Exon()
{
	start_exon = MAX;
	end_exon = 0;
	strand[0] = '\0';
	read_count = 0;
	coverage_base = NULL;
	read_count_Poisson = 0;

	parents = NULL;
	next_exon = NULL;
}

Exon::~Exon()
{
	if (coverage_base != NULL)
	{
		delete[] coverage_base;
	}

	parentTranscript *delparent, *curparent;
	curparent = parents;
	while(curparent != NULL)
	{
		delparent = curparent;
		curparent = delparent->next;
		delete delparent;
	}
	parents = NULL;
}

Exon *Exon::clone()
{
	long i;
	Exon *resultexon;
	resultexon = new Exon;

	resultexon->start_exon = start_exon;
	resultexon->end_exon = end_exon;
	strcpy(resultexon->strand, strand);
	resultexon->read_count = read_count;
	resultexon->coverage_base = new long[end_exon-start_exon+1];
	for (i = 0; i < end_exon-start_exon+1; i++)
	{
		resultexon->coverage_base[i] = 0;
	}

	resultexon->read_count_Poisson = read_count_Poisson;

	resultexon->next_exon = NULL;

	return resultexon;
}

Junction::Junction()
{
	start_juntion = MAX;
	end_juntion = 0;
	support = 0;

	parents = NULL;
	next_junction = NULL;
}

Junction::~Junction()
{
	parentTranscript *delparent, *curparent;
	curparent = parents;
	while(curparent != NULL)
	{
		delparent = curparent;
		curparent = delparent->next;
		delete delparent;
	}
	parents = NULL;
}

Junction * Junction::clone()
{
	Junction *resultjun;
	resultjun = new Junction;

	resultjun->start_juntion = start_juntion;
	resultjun->end_juntion = end_juntion;
	resultjun->support = support;

	resultjun->next_junction = NULL;

	return resultjun;
}


Transcript::Transcript()
{
	transID[0] = '\0';
	start_trans = MAX;
	end_trans = 0;
	exonNum = junNum = 0;
	abundance = 0.0;
	samplingProb = 0.0;
	transLength = 0;
	exons_tran = NULL;
	junctions_tran = NULL;
	fragments_tran = NULL;
	next_transcript = NULL;
}

Transcript::~Transcript()
{
	Fragment *delfrag, *curfrag;
	curfrag = fragments_tran;
	while(curfrag != NULL)
	{
		delfrag = curfrag;
		curfrag = delfrag->next_frag;
		delete delfrag;
	}
	fragments_tran = NULL;

	Exon *delexon, *curexon;
	curexon = exons_tran;
	while(curexon != NULL)
	{
		delexon = curexon;
		curexon = delexon->next_exon;
		delete delexon;
	}
	exons_tran = NULL;

	Junction *deljunction, *curjunction;
	curjunction = junctions_tran;
	while(curjunction != NULL)
	{
		deljunction = curjunction;
		curjunction = deljunction->next_junction;
		delete deljunction;
	}
	junctions_tran = NULL;
}

Gene::Gene()
{
	chromosome[0] = '\0';
	startPoint = MAX;
	endPoint = 0;
	strand[0] = '\0';
	tranNum = 0;
	exonNum = 0;
	junctionsNum = 0;

	transcripts = NULL;
	exons_gene = NULL;
	junctions_gene = NULL;
}

Gene::~Gene()
{
	Exon *delexon, *curexon;
	curexon = exons_gene;
	while(curexon != NULL)
	{
		delexon = curexon;
		curexon = delexon->next_exon;
		delete delexon;
	}
	exons_gene = NULL;

	Junction *deljunction, *curjunction;
	curjunction = junctions_gene;
	while(curjunction != NULL)
	{
		deljunction = curjunction;
		curjunction = deljunction->next_junction;
		delete deljunction;
	}
	junctions_gene = NULL;

	Transcript *deltrans, *curtrans;
	curtrans = transcripts;
	while(curtrans != NULL)
	{
		deltrans = curtrans;
		curtrans = deltrans->next_transcript;
		delete deltrans;
	}
	transcripts = NULL;
}

geneExonBoundary::geneExonBoundary()
{
	position = 0;
	next = NULL;
}

Read::Read()
{
	readNm[0] = '\0';
	chromosome[0] = '\0';
	start_Read = MAX;
	CIGAR[0] = '\0';
	TAG[0] = '\0';
}

Block::Block()
{
	int iLoop, jLoop;
	for (iLoop = 0; iLoop <= MAX_Trans_NUM; iLoop++)
	{
		transNameQueue[iLoop] = new char[MAX_TransNameLength];
		for (jLoop = 0; jLoop < MAX_TransNameLength; jLoop++)
		{
			transNameQueue[iLoop][jLoop] = '\0';
		}
	}
	ReadOrientedProb = new double[MAX_Trans_NUM + 1];
	for (iLoop = 0; iLoop <= MAX_Trans_NUM; iLoop++)
	{
		ReadOrientedProb[iLoop] = 0;
	}
	fragsInBlock = NULL;
	consumedEffectLength = 0;
	blocklength = 0;
	junctionCount = 0;
	blockCount = 0;
	next = NULL;
}

Block::~Block()
{
	if (ReadOrientedProb != NULL)
	{
		delete [] ReadOrientedProb;
	}
	for (int iLoop = 0; iLoop <= MAX_Trans_NUM; iLoop++)
	{
		if (transNameQueue[iLoop] != NULL)
		{
			delete [] transNameQueue[iLoop];
		}
	}
	Fragment *delfrag, *curfrag;
	curfrag = fragsInBlock;
	while(curfrag != NULL)
	{
		delfrag = curfrag;
		curfrag = delfrag->next_frag;
		delete delfrag;
	}
	fragsInBlock = NULL;
}

Block* Block::clone()
{
	Block *resultBlock = new Block;

	for (int iLoop = 0; transNameQueue[iLoop][0] != '\0'; iLoop++)
	{
		strcpy(resultBlock->transNameQueue[iLoop], transNameQueue[iLoop]);
		resultBlock->ReadOrientedProb[iLoop] = ReadOrientedProb[iLoop];
	}

	// copy the information of pathJunction
	Fragment *listTail, *curList, *newlist;
	listTail = NULL;
	curList = fragsInBlock;
	while(curList != NULL)
	{
		newlist = new Fragment;
		newlist = curList->clone();

		if (resultBlock->fragsInBlock == NULL)
		{
			resultBlock->fragsInBlock = newlist;
			listTail = newlist;
		}
		else
		{
			listTail->next_frag = newlist;
			listTail = newlist;
		}

		curList = curList->next_frag;

	}

	resultBlock->consumedEffectLength = consumedEffectLength;
	resultBlock->blocklength = blocklength;
	resultBlock->junctionCount = junctionCount;
	resultBlock->blockCount = blockCount;

	return resultBlock;
}

Fragment::Fragment()
{
	type = -1;
	startPoint = MAX;
	endPoint = 0;
	next_frag = NULL;
}

Fragment* Fragment::clone()
{
	Fragment *resultFragment;

	resultFragment = new Fragment;
	resultFragment->type = type;
	resultFragment->startPoint = startPoint;
	resultFragment->endPoint = endPoint;
	resultFragment->next_frag = NULL;

	return resultFragment;
}


long ExonNum = 0;
long ReadNum = 0;
Read *readList[10000000];

double mergeSort_Larray[10000000];
double mergeSort_Rarray[10000000];
void* mergeSort_LorderedList[10000000];
void* mergeSort_RorderedList[10000000];
double sortKey[10000000]; 
void* sortList[10000000];

void merge(long p, long q, long r)
{
	long n1, n2, i, j, k;

	n1 = q - p + 1;
	n2 = r - q;

	for (i = 1; i <= n1; i++)
	{
		mergeSort_Larray[i] = sortKey[p + i - 1];
		mergeSort_LorderedList[i] = sortList[p + i - 1];
	}
	for (j = 1; j <= n2; j++)
	{
		mergeSort_Rarray[j] = sortKey[q + j];
		mergeSort_RorderedList[j] = sortList[q + j];
	}

	mergeSort_Larray[n1 + 1] = MAX_CHR_LENGTH * 2;
	mergeSort_Rarray[n2 + 1] = MAX_CHR_LENGTH * 2;

	i = 1;
	j = 1;

	for (k = p; k <= r; k++)
	{
		if (mergeSort_Larray[i] <= mergeSort_Rarray[j])
		{
			sortKey[k] = mergeSort_Larray[i];
			sortList[k] = mergeSort_LorderedList[i];

			i++;
		} 
		else
		{
			sortKey[k] = mergeSort_Rarray[j];
			sortList[k] = mergeSort_RorderedList[j];

			j++;
		}
	}

	return;
}


void mergeSort(long sortList_size)
{
	//non-recursive merge sort for sorting junctions
	long m, n, i, r;
	m = 1;
	n = sortList_size;

	while (m <= n)
	{
		i = 1;
		while (i <= n - m)
		{
			r = (i + 2 * m - 1) < n ? (i + 2 * m - 1) : n;
			merge(i, i + m - 1, r);
			i = i + 2 * m;
		}

		m = m * 2;
	}

	return;
}

void CopyGTFfile(char *outputfilename, char *inputfilename)
{
	char chromosome[100];
	string info;
	ofstream outputfile;
	ifstream inputfile;
	outputfile.open(outputfilename, fstream::in | fstream::out | fstream::app);

	inputfile.open(inputfilename);
	chromosome[0] = '\0';
	inputfile >> chromosome;
	while(chromosome[0] != '\0')
	{
		getline(inputfile, info);
		outputfile << chromosome << info << endl;
		chromosome[0] = '\0';
		inputfile >> chromosome;
	}
	outputfile.close();
	inputfile.close();

	return;
}

// Get gene ends from geneID
void getEnd(char *geneName, long &start, long &end, char *strand)
{
	int i, tmp1, tmp2;
	char startPoint[1000], endPoint[1000];
	i = tmp1 = tmp2 = 0;
	while(geneName[i] != '-')
	{
		startPoint[tmp1] = geneName[i];
		i++;
		tmp1++;
	}
	startPoint[tmp1] = '\0';
	i++;
	while(geneName[i] != 'W' && geneName[i] != 'C')
	{
		endPoint[tmp2] = geneName[i];
		i++;
		tmp2++;
	}
	endPoint[tmp2] = '\0';

	start = atol(startPoint);
	end = atol(endPoint);

	strand[0] = geneName[i];
	strand[1] = '\0';

}

long startOld, endOld;

bool input_Next = true, inserted = false;
ifstream inputGeneNameNext;
char geneNamesNext[200]; 
string infoNext;
void processSecondGTF(long &start, long &end, char *GeneNamesCombined, char *GTFfile, char *outputfilePath, char *GTFpath, char *ChrName)
{
	ofstream outputfile;
	char comd[2000], inputfilename[1000], outputfilename[1000];
	long startNext, endNext;
	char strandNext[10];

	if (input_Next == true)
	{	
		geneNamesNext[0] = '\0';
		inputGeneNameNext >> geneNamesNext;
		inserted = false;
	}
	while(geneNamesNext[0] != '\0')
	{
		if (input_Next == true)
		{
			getline(inputGeneNameNext, infoNext);
		}
		getEnd(geneNamesNext, startNext, endNext, strandNext);

		// Different cases
		if (endNext < start)
		{
			if (startNext > endOld)
			{
				outputfile.open(GeneNamesCombined, fstream::in | fstream::out | fstream::app);
				outputfile << startNext << '-' << endNext << endl;
				outputfile.close();
				sprintf(inputfilename, "%s%s%s/%ld-%ld%s", GTFpath, ChrName, strandNext, startNext, endNext, strandNext);
				sprintf(outputfilename, "%s%s/%ld-%ld", outputfilePath, ChrName, startNext, endNext);
				CopyGTFfile(outputfilename, inputfilename);
				inserted = true;
			}
			input_Next = true;
		}
		else if (startNext > end)
		{	
			input_Next = false;
			break;
		}
		else if (startNext <= start && (endNext >= start && endNext <= end))
		{
			if (inserted == false)
			{
				sprintf(inputfilename, "%s%s%s/%ld-%ld%s", GTFpath, ChrName, strandNext, startNext, endNext, strandNext);
				CopyGTFfile(GTFfile, inputfilename);
				startOld = start;
				start = startNext;
				inserted = true;
			}			
			input_Next = true;
		}
		else if (startNext <= start && endNext > end)
		{
			sprintf(inputfilename, "%s%s%s/%ld-%ld%s", GTFpath, ChrName, strandNext, startNext, endNext, strandNext);
			CopyGTFfile(GTFfile, inputfilename);
			startOld = start;
			endOld = end;
			start = startNext;
			end = endNext;
			input_Next = false;
			inserted = true;
			break;
		}
		else if (startNext > start && (endNext > start && endNext <= end))
		{
			if (inserted == false)
			{
				sprintf(inputfilename, "%s%s%s/%ld-%ld%s", GTFpath, ChrName, strandNext, startNext, endNext, strandNext);
				CopyGTFfile(GTFfile, inputfilename);
				inserted = true;
			}
			input_Next = true;
		}
		else if ((startNext > start&& startNext <= end) && endNext >= end)
		{
			if (inserted == false)
			{
				sprintf(inputfilename, "%s%s%s/%ld-%ld%s", GTFpath, ChrName, strandNext, startNext, endNext, strandNext);
				CopyGTFfile(GTFfile, inputfilename);
				endOld = end;
				end = endNext;
				input_Next = false;
				inserted = true;
				break;
			}
			else
			{
				input_Next = true;
			}
		}

		if (input_Next == true)
		{	
			geneNamesNext[0] = '\0';
			inputGeneNameNext >> geneNamesNext;
			inserted = false;
		}
	}
	return;
}

void MergeOverlapGenes(char *GTFpath, char *ChrName, char *outputfilePath)
{
	char comd[2000], GeneNamesFirst[1000], GeneNamesNext[1000], GeneNamesCombined[1000], GTFfile[1000], inputfilename[1000], namesFirst[200], namesNext[200], strandFirst[10], strandNext[10];
	string infoFirst, infoNext;
	long startFirst, endFirst, startNext, endNext, start, end;
	ifstream inputGeneNameFirst;
	ofstream outputGeneName;


	sprintf(GeneNamesFirst, "%s%sW/GeneName.txt", GTFpath, ChrName);
	sprintf(GeneNamesNext, "%s%sC/GeneName.txt", GTFpath, ChrName);
	inputGeneNameFirst.open(GeneNamesFirst);
	inputGeneNameNext.open(GeneNamesNext);
	namesFirst[0] = '\0';
	inputGeneNameFirst >> namesFirst;
	getEnd(namesFirst, startFirst, endFirst, strandFirst);
	namesNext[0] = '\0';
	inputGeneNameNext >> namesNext;
	getEnd(namesNext, startNext, endNext, strandNext);
	inputGeneNameFirst.close();
	inputGeneNameNext.close();

	startOld = MAX;
	endOld = (-1) * MAX;
	if (startFirst <= startNext)
	{
		start = startFirst;
		end = endFirst;
		sprintf(GeneNamesFirst, "%s%sW/GeneName.txt", GTFpath, ChrName);
		sprintf(GeneNamesNext, "%s%sC/GeneName.txt", GTFpath, ChrName);
	}
	else
	{
		start = startNext;
		end = endNext;
		sprintf(GeneNamesFirst, "%s%sC/GeneName.txt", GTFpath, ChrName);
		sprintf(GeneNamesNext, "%s%sW/GeneName.txt", GTFpath, ChrName);
	}
	sprintf(GeneNamesCombined,"%s%s/GeneName.txt", outputfilePath, ChrName);
	sprintf(GTFfile,"%s%s/temp.txt", outputfilePath, ChrName);	

	inputGeneNameFirst.open(GeneNamesFirst);
	inputGeneNameNext.open(GeneNamesNext);
	// Input the geneNames of GeneName files which first gene starting first
	input_Next = true;
	namesFirst[0] = '\0';
	inputGeneNameFirst >> namesFirst;

	while(namesFirst[0] != '\0')
	{
		getEnd(namesFirst, startFirst, endFirst, strandFirst);

		if (startFirst > end)
		{
			sprintf(comd, "mv %s %s%s/%ld-%ld", GTFfile, outputfilePath, ChrName, start, end);
			system(comd);
			outputGeneName.open(GeneNamesCombined, fstream::in | fstream::out | fstream::app);
			outputGeneName << start << '-' << end << endl;
			outputGeneName.close();
			startOld = start;
			endOld = end;
			start = startFirst;
			end = endFirst;
		}
		else if (endFirst > end)
		{
			end = endFirst;
		}

		sprintf(inputfilename, "%s%s%s/%ld-%ld%s", GTFpath, ChrName, strandFirst, startFirst, endFirst, strandFirst);
		CopyGTFfile(GTFfile, inputfilename);
		processSecondGTF(start, end, GeneNamesCombined, GTFfile, outputfilePath, GTFpath, ChrName);
// 		startOld = start;
// 		endOld = end;

		namesFirst[0] = '\0';
		inputGeneNameFirst >> namesFirst;
	}

	outputGeneName.open(GeneNamesCombined, fstream::in | fstream::out | fstream::app);
	outputGeneName << start << '-' << end << endl;
	outputGeneName.close();
	sprintf(comd, "mv %s %s%s/%ld-%ld", GTFfile, outputfilePath, ChrName, start, end);
	system(comd);

	inputGeneNameFirst.close();
	inputGeneNameNext.close();

	return;
}

// From like "chr2C" get the chromsome name "chr2" and the strand "C"
void GetChrStrand(char *name, char *chromosome, char *strand)
{
	int iLoop, tmp;

	for (iLoop = 0, tmp = 0; name[iLoop] != 'C' && name[iLoop] != 'W'; iLoop++, tmp++)
	{
		chromosome[tmp] = name[iLoop];
	}
	chromosome[tmp] = '\0';
	strand[0] = name[iLoop];
	strand[1] = '\0';

	return;
}


long geneListNum;
Gene *geneList[MAX_Gene];

void getTranscriptsFromGTF(char *gtf_path, char *geneName)
	//this is for GTF format!!
{
	char inputfilename[500];
	sprintf(inputfilename, "%s%s", gtf_path, geneName);
	ifstream inputfile;
	inputfile.open(inputfilename);

	bool newTranscript;
	char chrNm[100], chromosome[50], lineCategory[100], strand[5], geneID[300], transID[300], tmpChar[100];
	int tmp;
	long start, end, iLoop;
	string otherInfo;
	Transcript *curTrans, *newTrans;
	Exon *newExon;
	Gene *curGene;
	curGene = new Gene;
	getEnd(geneName, start, end, strand);
	curGene->startPoint = start;
	curGene->endPoint = end;

	for (tmp = 0; tmp < 100; tmp++)
	{
		chrNm[tmp] = '\0';
	}

	inputfile >> chrNm;
	if (chrNm[0] != '\0')
	{
		//		GetChrStrand(chrNm, chromosome, strand);
		strcpy(curGene->chromosome, chrNm);
		strcpy(curGene->strand, strand);
	}
	while (chrNm[0] != '\0')
	{
		inputfile >> tmpChar;
		inputfile >> lineCategory;
		inputfile >> start;
		inputfile >> end;
		inputfile >> tmpChar;
		inputfile >> strand;
		inputfile >> tmpChar;
		inputfile >> tmpChar;
		inputfile >> geneID;
		inputfile >> tmpChar;
		inputfile >> transID;
		getline(inputfile, otherInfo);

		if (strcmp(lineCategory, "exon") == 0)
		{
			for (tmp = 0; geneID[tmp+1] != '\"'; tmp++)
			{
				geneID[tmp] = geneID[tmp+1];
			}
			geneID[tmp] = '\0';

			for (tmp = 0; transID[tmp+1] != '\"'; tmp++)
			{
				transID[tmp] = transID[tmp+1];
			}
			transID[tmp] = '\0';

			// insert this transcript into curGene if it is new
			curTrans = curGene->transcripts;
			newTranscript = true;
			if (curTrans == NULL)
			{
				newTranscript = true;
				newTrans = new Transcript;
				strcpy(newTrans->transID, transID);
				curTrans = curGene->transcripts = newTrans;
				curGene->tranNum++;
			}
			else
			{
				while(curTrans != NULL)
				{
					if (strcmp(curTrans->transID, transID) == 0)
					{
						newTranscript = false;
						break;
					}
					curTrans = curTrans->next_transcript;
				}
				if (newTranscript == true)
				{
					// this is a new transcript, insert it into the geneList
					newTrans = new Transcript;
					strcpy(newTrans->transID, transID);
					curTrans = curGene->transcripts;
					while (curTrans->next_transcript != NULL)
					{
						curTrans = curTrans->next_transcript;
					}
					curTrans->next_transcript = newTrans;
					curTrans = newTrans;
					curGene->tranNum++;
				}
			}

			//make a new exon for the transcript
			newExon = new Exon;

			if (strcmp(strand, "+") == 0)
			{
				strcpy(newExon->strand, "+");
			} 
			else if (strcmp(strand, "-") == 0)
			{
				strcpy(newExon->strand, "-");
			}
			else
			{
				cout << "Error: unrecognized strand. Please confirm... ";
				cin >> tmpChar;
				exit(1);
			}

			newExon->start_exon = start;
			newExon->end_exon = end;
			newExon->next_exon = curTrans->exons_tran;
			curTrans->exons_tran = newExon;

			if (start < curTrans->start_trans)
			{
				curTrans->start_trans = start;
			}
			if (end	> curTrans->end_trans)
			{
				curTrans->end_trans = end;
			}
		}
		else
		{
			//do nothing
		}

		chrNm[0] = '\0';
		inputfile >> chrNm;		
	}

	geneListNum++;
	geneList[geneListNum] = curGene;

	inputfile.close();

	return;
}


void makeGeneExons(long geneIndex)
{
	long iLoop, jLoop, kLoop, exonCnt, splicesite_cnt, *splicesiteList, curExon_start, curExon_end;
	Gene *curGene;
	Transcript *curTrans;
	Exon *curExon, *curGeneExon, *newExon, *deleteExon;
	Junction *newJunc, *curJunc, *curGeneJunc;
	bool exonExist, juncExist, splicesiteExist;
	geneExonBoundary *boundary_head, *boundary_2ndlast, *boundary_new; //2nd last: where new ones should be inserted
	parentTranscript *newParent, *curParent;

	curGene = geneList[geneIndex];
	curGene->exons_gene = NULL;
	curGene->junctions_gene = NULL;

	//build junction list
	curTrans = curGene->transcripts;
	while (curTrans != NULL)
	{
		//sort the exon list 
		exonCnt = 0;
		curExon = curTrans->exons_tran;
		while (curExon != NULL)
		{
			exonCnt++;
			sortKey[exonCnt]  = double(curExon->start_exon);
			sortList[exonCnt] = (void*)(curExon);

			curExon = curExon->next_exon;
		}
		mergeSort(exonCnt);

		curTrans->exons_tran = NULL;
		for (jLoop = exonCnt; jLoop >= 1 ; jLoop--)
		{
			((Exon*)sortList[jLoop])->next_exon = curTrans->exons_tran;
			curTrans->exons_tran = (Exon*)sortList[jLoop];
		}
		curTrans->exonNum = exonCnt;

		//build junction list
		curTrans->junctions_tran = NULL;
		for (jLoop = exonCnt; jLoop > 1 ; jLoop--)
		{
			newJunc = new Junction;
			newJunc->start_juntion = ((Exon*)sortList[jLoop-1])->end_exon;
			newJunc->end_juntion   = ((Exon*)sortList[jLoop])->start_exon;
			newJunc->next_junction  = curTrans->junctions_tran;
			curTrans->junctions_tran = newJunc;
			curTrans->junNum += 1;
		}

		curTrans = curTrans->next_transcript;
	}

	//build gene junction list
	curTrans = curGene->transcripts;
	while (curTrans != NULL)
	{
		curJunc = curTrans->junctions_tran;
		while (curJunc != NULL)
		{
			juncExist = false;
			curGeneJunc = curGene->junctions_gene;
			while (curGeneJunc != NULL)
			{
				if (curJunc->start_juntion == curGeneJunc->start_juntion && curJunc->end_juntion == curGeneJunc->end_juntion)
				{
					juncExist = true;

					newParent = new parentTranscript;
					newParent->parent = curTrans;
					newParent->next = curGeneJunc->parents;
					curGeneJunc->parents = newParent;


					break;
				}
				curGeneJunc = curGeneJunc->next_junction;
			}

			if (juncExist == false)
			{
				newJunc = new Junction;
				newJunc->start_juntion = curJunc->start_juntion;
				newJunc->end_juntion   = curJunc->end_juntion;
				newJunc->next_junction  = curGene->junctions_gene;

				newParent = new parentTranscript;
				newParent->parent = curTrans;
				newJunc->parents = newParent;

				curGene->junctions_gene = newJunc;
				curGene->junctionsNum += 1;
			}

			curJunc = curJunc->next_junction;
		}

		curTrans = curTrans->next_transcript;
	}

	//build splice sites list !! ADD exon start and end... vegfa is an example 
	jLoop = 0;
	curGeneJunc = curGene->junctions_gene;
	while (curGeneJunc != NULL)
	{
		splicesiteExist = false;
		for (kLoop = 1; kLoop <= jLoop; kLoop++)
		{
			if (double(curGeneJunc->start_juntion) == sortKey[kLoop])
			{
				splicesiteExist = true;
				break;
			}
		}
		if (splicesiteExist == false)
		{
			jLoop++;
			sortList[jLoop] = NULL;
			sortKey[jLoop]  = double(curGeneJunc->start_juntion);
		}

		splicesiteExist = false;
		for (kLoop = 1; kLoop <= jLoop; kLoop++)
		{
			if (double(curGeneJunc->end_juntion) == sortKey[kLoop])
			{
				splicesiteExist = true;
				break;
			}
		}
		if (splicesiteExist == false)
		{
			jLoop++;
			sortList[jLoop] = NULL;
			sortKey[jLoop]  = double(curGeneJunc->end_juntion);
		}

		curGeneJunc = curGeneJunc->next_junction;
	}

	curTrans = curGene->transcripts;
	while (curTrans != NULL)
	{
		curExon = curTrans->exons_tran;
		while (curExon != NULL)
		{
			splicesiteExist = false;
			for (kLoop = 1; kLoop <= jLoop; kLoop++)
			{
				if (double(curExon->start_exon) == sortKey[kLoop])
				{
					splicesiteExist = true;
					break;
				}
			}
			if (splicesiteExist == false)
			{
				jLoop++;
				sortList[jLoop] = NULL;
				sortKey[jLoop]  = double(curExon->start_exon);
			}

			splicesiteExist = false;
			for (kLoop = 1; kLoop <= jLoop; kLoop++)
			{
				if (double(curExon->end_exon) == sortKey[kLoop])
				{
					splicesiteExist = true;
					break;
				}
			}
			if (splicesiteExist == false)
			{
				jLoop++;
				sortList[jLoop] = NULL;
				sortKey[jLoop]  = double(curExon->end_exon);
			}

			curExon = curExon->next_exon;
		}

		curTrans = curTrans->next_transcript;
	}

	splicesite_cnt = jLoop;
	mergeSort(splicesite_cnt);

	splicesiteList = new long [splicesite_cnt+1];
	for (jLoop = 1; jLoop <= splicesite_cnt; jLoop++)
	{
		splicesiteList[jLoop] = long(sortKey[jLoop]);
	}


	//build gene exon list: cut exons & throw away redundant ones
	curTrans = curGene->transcripts;
	while (curTrans != NULL)
	{
		jLoop = 1;
		curExon = curTrans->exons_tran;
		while (curExon != NULL)
		{
			boundary_head = new geneExonBoundary;
			boundary_head->position = curExon->start_exon;
			boundary_new = new geneExonBoundary;
			boundary_new->position = curExon->end_exon;
			boundary_head->next = boundary_new;
			boundary_2ndlast = boundary_head;

			for (; jLoop <= splicesite_cnt && splicesiteList[jLoop] <= curExon->end_exon; jLoop++)
			{
				if (splicesiteList[jLoop] > curExon->start_exon && splicesiteList[jLoop] < curExon->end_exon)
				{
					boundary_new = new geneExonBoundary;
					boundary_new->position = splicesiteList[jLoop];
					boundary_new->next = boundary_2ndlast->next;
					boundary_2ndlast->next = boundary_new;
					boundary_2ndlast = boundary_new;
				}
			}

			boundary_new = boundary_head;
			while (boundary_new->next != NULL)
			{
				curExon_start = boundary_new->position;
				curExon_end   = boundary_new->next->position;

				exonExist = false;
				curGeneExon = curGene->exons_gene;
				while (curGeneExon != NULL)
				{
					if (curExon_start == curGeneExon->start_exon && curExon_end == curGeneExon->end_exon)
					{
						exonExist = true;

						newParent = new parentTranscript;
						newParent->parent = curTrans;
						newParent->next = curGeneExon->parents;
						curGeneExon->parents = newParent;

						break;
					}
					curGeneExon = curGeneExon->next_exon;
				}

				if (exonExist == false)
				{
					newExon = new Exon;
					newExon->start_exon = curExon_start;
					newExon->end_exon   = curExon_end;
					newExon->next_exon  = curGene->exons_gene;

					newParent = new parentTranscript;
					newParent->parent = curTrans;
					newExon->parents = newParent;

					curGene->exons_gene = newExon;
					curGene->exonNum += 1;
				}

				boundary_new = boundary_new->next;
			}

			curExon = curExon->next_exon;
		}

		curTrans = curTrans->next_transcript;
	}

	//clean up
	delete [] splicesiteList;

	//sort the exon list for this gene
	exonCnt = 0;
	curExon = curGene->exons_gene;
	while (curExon != NULL)
	{
		exonCnt++;
		sortKey[exonCnt]  = double(curExon->start_exon);
		sortList[exonCnt] = (void*)(curExon);
		curExon = curExon->next_exon;
	}
	mergeSort(exonCnt);

	curGene->exons_gene = NULL;
	for (jLoop = exonCnt; jLoop >= 1 ; jLoop--)
	{
		((Exon*)sortList[jLoop])->next_exon = curGene->exons_gene;
		curGene->exons_gene = (Exon*)sortList[jLoop];
	}

	// Adjust exon boundaries of the gene

	curExon = curGene->exons_gene;
	while(curExon->next_exon != NULL)
	{
		if (curExon->end_exon == curExon->next_exon->start_exon)
		{
			curJunc = curGene->junctions_gene;
			while(curJunc != NULL)
			{
				if (curJunc->start_juntion == curExon->end_exon)
				{
					curExon->next_exon->start_exon = curExon->next_exon->start_exon + 1;
				}
				else if (curJunc->end_juntion == curExon->end_exon)
				{
					curExon->end_exon = curExon->end_exon - 1;
				}
				curJunc = curJunc->next_junction;
			}

		}
		curExon = curExon->next_exon;
	}


	// rebuild the exonlist and fragment list for transcripts
	curTrans = curGene->transcripts;
	while(curTrans != NULL)
	{
		// build fragment
		Fragment *newFrag, *curFrag;
		curExon = curTrans->exons_tran;
		while (curExon != NULL)
		{
			newFrag = new Fragment;
			newFrag->type = 1;
			newFrag->startPoint = curExon->start_exon;
			newFrag->endPoint = curExon->end_exon;
			curTrans->transLength += newFrag->endPoint - newFrag->startPoint + 1;
			if(curTrans->fragments_tran == NULL)
			{
				curFrag = curTrans->fragments_tran = newFrag;
			}
			else
			{
				curFrag->next_frag = newFrag;
				curFrag = newFrag;
			}
			if (curExon->next_exon != NULL)
			{
				if ((curExon->next_exon->start_exon - curExon->end_exon) > 1)
				{
					newFrag = new Fragment;
					newFrag->type = 0;
					newFrag->startPoint = curExon->end_exon;
					newFrag->endPoint = curExon->next_exon->start_exon;
					curFrag->next_frag = newFrag;
					curFrag = newFrag;
				}
			}

			curExon = curExon->next_exon;
		}


		curExon = curTrans->exons_tran;
		while (curExon != NULL)
		{
			deleteExon = curExon;
			curExon = deleteExon->next_exon;
			delete deleteExon;

		}

		curTrans->exons_tran = NULL;

		// insert exons into transcripts
		curExon = curGene->exons_gene;
		while (curExon != NULL)
		{
			curParent = curExon->parents;
			while(curParent != NULL)
			{
				if (strcmp(curTrans->transID, curParent->parent->transID) == 0)
				{
					newExon = new Exon;
					newExon->start_exon = curExon->start_exon;
					newExon->end_exon   = curExon->end_exon;
					newExon->next_exon  = curTrans->exons_tran;

					curTrans->exons_tran = newExon;
					break;
				}
				curParent = curParent->next;
			}
			curExon = curExon->next_exon;
		}

		//sort the exon list 
		exonCnt = 0;
		curExon = curTrans->exons_tran;
		while (curExon != NULL)
		{
			exonCnt++;
			sortKey[exonCnt]  = double(curExon->start_exon);
			sortList[exonCnt] = (void*)(curExon);

			curExon = curExon->next_exon;
		}
		mergeSort(exonCnt);

		curTrans->exons_tran = NULL;
		for (jLoop = exonCnt; jLoop >= 1 ; jLoop--)
		{
			((Exon*)sortList[jLoop])->next_exon = curTrans->exons_tran;
			curTrans->exons_tran = (Exon*)sortList[jLoop];
		}
		curTrans->exonNum = exonCnt;

		curTrans = curTrans->next_transcript;
	}

}


int main(int argc, char* argv[])
{
	if (argc != 4)
	{
		cout << argv[0] << "\t<inputfile_gtf_path>" << "\t<chromosome>" << "\t<GTFpath>" << endl;
		return 1;
	}

	MergeOverlapGenes(argv[1], argv[2], argv[3]);

	return 0;
}



