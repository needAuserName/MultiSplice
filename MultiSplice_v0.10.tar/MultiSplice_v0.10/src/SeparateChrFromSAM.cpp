#define UNIX

#ifdef UNIX

#include <fstream>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cstdlib> 
#include <ctime>
#include <assert.h>
#include <algorithm>

#else

#include <fstream>
#include <string>
#include <iostream>
#include <math.h>
#include <stdlib.h> 
#include <time.h>
#include <assert.h>
#include <algorithm>

#endif


using namespace std;



char targetChromosome[500][50];
int targetChrNum;

class reads
{
public:
	char name[100];
	char field1[100];
	char field2[100];
	char field3[100];
	char field4[100];
	char field5[100];

	reads();
};

long readAlignIndex[500];
long totalReadNum;
//reads *readAlign[500][1000000];

ofstream outputfile[500];

char lastTimeName[100];
char dirPrefix[400];

ofstream abnormal_reads;
ofstream dropped_reads;

reads::reads()
{
	for (int i = 0; i < 100; i++)
	{
		name[i] = '\0';
		field1[i] = '\0';
		field2[i] = '\0';
		field3[i] = '\0';
		field4[i] = '\0';
		field5[i] = '\0';
	}
}



void process(reads* curRead)
{
	//output a single read
	char chromosome[100], outputfilename[500];
	int tmp, i;

	strcpy(chromosome, curRead->field2);

	for (tmp = 1; tmp <= targetChrNum; tmp++)
	{
		if (strcmp(targetChromosome[tmp], chromosome) == 0)
		{
			break;
		}
	}

	if (tmp > targetChrNum)
	{
		//chromosome not found
		sprintf(outputfilename, "%s%s.txt", dirPrefix, chromosome);
		outputfile[tmp].open(outputfilename);

		targetChrNum++;
		strcpy(targetChromosome[targetChrNum], chromosome);		
	}

	readAlignIndex[tmp]++;
//	readAlign[tmp][readAlignIndex[tmp]] = curRead;

	outputfile[tmp] << curRead->name << "\t" << curRead->field1 << "\t" << curRead->field2 << "\t" << curRead->field3 << "\t" << curRead->field4 << "\t" << curRead->field5 << endl; 


	if (strcmp(lastTimeName, curRead->name) == 0)
	{
		delete curRead;
		return;
	}

	strcpy(lastTimeName, curRead->name);
	totalReadNum++;

	delete curRead;
	return;
}


void outputRead()
{
	int i, j;
	char outputfilename[500];
	reads *outputread;
	ofstream outputChrname;
	long totalAlignNum = 0;

	sprintf(outputfilename, "%sChromosomeName.txt", dirPrefix);
	outputChrname.open(outputfilename);

	for (i = 1; i <= targetChrNum; i++)
	{
		outputChrname << targetChromosome[i] << '\t' << readAlignIndex[i] << endl; 
		totalAlignNum += readAlignIndex[i];

		outputfile[i].close();
	}

	outputChrname << totalReadNum << '\t' << totalAlignNum << endl;

	outputChrname.close();
	dropped_reads.close();
	abnormal_reads.close();

	return;
}


void parse(char* inputfilename)
{
	reads *ptr;
	ptr = NULL;

	ifstream inputfile;
	inputfile.open(inputfilename);

	char name[100], curName[100];
	int strand, tmp, i;
	string info;


	for (tmp = 0; tmp < 100; tmp++)
	{
		name[tmp] = '\0';
	}

	inputfile >> name;

	while (name[1] != '\0')
	{
		for (tmp = 0; tmp < 100; tmp++)
		{
			if (name[tmp] == '/')
			{
				break;
			}
		}
		name[tmp] = '\0'; 

		ptr = new reads;

		strcpy(ptr->name, name);
		inputfile >> ptr->field1;
		inputfile >> ptr->field2;
		inputfile >> ptr->field3;
		inputfile >> ptr->field4;
		inputfile >> ptr->field5;

		getline(inputfile, info);

		process(ptr);

		name[1] = '\0';

		inputfile >> name;		
	}


	inputfile.close();

	return;
}


void initialization()
{
	int i;

// 	for (i = 0; i < 500; i++)
// 	{
// 		readAlignIndex[i] = 0;
// 	}

	targetChrNum = 0;
	totalReadNum = 0;
	sprintf(lastTimeName, "XXXX");

	return;
}


int main(int argc, char* argv[])
{
//	sprintf(dirPrefix, ".");

	if (argc != 3)
	{
		cout << argv[0] << "\t<filename>\t<target_path>" << endl;
		return 1;
	}

	strcpy(dirPrefix, argv[2]);

	if (strcmp(dirPrefix, "./") == 0)
		sprintf(dirPrefix, "./data/tmp/");

	char outpurfilename[500];
	sprintf(outpurfilename, "%sDroppedReads.txt", dirPrefix);
	dropped_reads.open(outpurfilename);
	sprintf(outpurfilename, "%sAbnormalReads.txt", dirPrefix);
	abnormal_reads.open(outpurfilename);

	char inputfilename[500];
	strcpy(inputfilename, argv[1]);


	initialization();

	parse(inputfilename);

	outputRead();

	return 0;
}