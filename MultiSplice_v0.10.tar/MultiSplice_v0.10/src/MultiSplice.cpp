/*    
 *    MultiSplice.cpp		
 *    MultiSplice
 *
 *    Copyright (C) 2012 University of Kentucky and
 *                       Yan Huang
 *
 *    Authors: Yan Huang
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#define UNIX

#ifdef UNIX

#include <fstream>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cstdlib> 
#include <ctime>
#include <assert.h>
#include <algorithm>

#else

#include <fstream>
#include <string>
#include <iostream>
#include <math.h>
#include <stdlib.h> 
#include <time.h>
#include <assert.h>
#include <algorithm>

#endif


using namespace std;


char chrName[100][100];
int chrNum;

void inputChrName(char *namefile);


int main(int argc, char* argv[])
{
	if (argc != 7)
	{
		cout << argv[0] << "<MultiSplicePath>\t<GTFFileName>\t<SAMFileName>\t<OutputFilePath>\t<ReadLength>\t<FragmentLength>" << endl;
		return 1;
	}

	char comd[5000];
	int i;
	char filepath[2000];

	sprintf(filepath, "%sbin/", argv[1]);
	i = chdir(filepath);

	// Separate GTF file by Chromosomes
	sprintf(comd, "mkdir %sGTF", argv[4]);
	i = system(comd);
	sprintf(comd, "./SeparateChrFromGTF %s %sGTF/", argv[2], argv[4]);
	i = system(comd);

	// Separate GTF by Gene
	sprintf(filepath, "%sGTF/", argv[4]);
	inputChrName(filepath);
	cout << "Total #chr = " << chrNum << endl;
	int chrLoopCnt = 0;

	for (chrLoopCnt = 0; chrLoopCnt < chrNum; chrLoopCnt++)
	{
		sprintf(comd, "./SeparateGeneFromGTF %sGTF/%s.gtf %sGTF/ %s", argv[4], chrName[chrLoopCnt], argv[4], chrName[chrLoopCnt], chrName[chrLoopCnt]);
		i = system(comd);
	}
	for (chrLoopCnt = 0; chrLoopCnt < chrNum; chrLoopCnt++)
	{
		sprintf(comd, "rm %sGTF/%s.gtf", argv[4], chrName[chrLoopCnt]);
		i = system(comd);
	}
	cout << "Parse GTFile done!" << endl;

	// Parse SAM file
	sprintf(comd, "mkdir %sSAM", argv[4]);
	i = system(comd);
	sprintf(comd, "./SeparateChrFromSAM %s %sSAM/", argv[3], argv[4]);
	i = system(comd);
	sprintf(comd, "mkdir %sSAM/tmp", argv[4]);
	i = system(comd);
	for (chrLoopCnt = 0; chrLoopCnt < chrNum; ++chrLoopCnt)
	{
		sprintf(comd, "mkdir %sSAM/tmp/%s", argv[4], chrName[chrLoopCnt]);
		i = system(comd);
	}
	int sampleCnt = 1;
	for (chrLoopCnt = 0; chrLoopCnt < chrNum; ++chrLoopCnt)
	{
		sprintf(comd, "./fragment %sSAM/ %s %d noDB %sSAM/tmp/%s/", argv[4], chrName[chrLoopCnt], sampleCnt, argv[4], chrName[chrLoopCnt]);
		i = system(comd);

	}
	cout << "Parse SAMFile done!" << endl;

	// Construct the structures of each gene
	sprintf(comd, "mkdir %sresult", argv[4]);
	i = system(comd);
	for (chrLoopCnt = 0; chrLoopCnt < chrNum; ++chrLoopCnt)
	{
		sprintf(comd, "mkdir %sresult/%s", argv[4], chrName[chrLoopCnt]);
		i = system(comd);
		sprintf(comd, "./Estimate %sGTF/%s/ %sSAM/tmp/%s/ %sresult/%s/ %d %d %d", argv[4], chrName[chrLoopCnt], argv[4], chrName[chrLoopCnt], argv[4], chrName[chrLoopCnt], atoi(argv[5]), atoi(argv[5]), atoi(argv[6]));
		i = system(comd);
	}
	cout << "Temporary results generated!" << endl;

	// Run matlab
// 	char GTFPath[2000], OutputFilePath[2000];
// 	for (chrLoopCnt = 0; chrLoopCnt < chrNum; ++chrLoopCnt)
// 	{
// 		sprintf(GTFPath, "%sGTF/", argv[4]);
// 		sprintf(OutputFilePath, "%sresult/", argv[4]);
// 		sprintf(comd,  "matlab -r \"Estimate_backup('%s', '%s', '%s');exit;\"", chrName[chrLoopCnt], GTFPath, OutputFilePath);
// 		i = system(comd);
// 	}

// 	// Run matlab
	char ChrNameList[2000], GTFPath[2000], OutputFilePath[2000];
	sprintf(ChrNameList, "%sGTF/ChromosomeName.txt", argv[4]);
	sprintf(GTFPath, "%sGTF/", argv[4]);
	sprintf(OutputFilePath, "%sresult/", argv[4]);
	sprintf(comd,  "matlab -r \"Estimate('%s, %s, %s');exit;\"", ChrNameList, GTFPath, OutputFilePath);
	system(comd);

	// Finalize results
	char outputfilename[2000];
	sprintf(outputfilename, "%sestimation.results", argv[4]);
	ofstream outputfile;
	outputfile.open(outputfilename);
	outputfile << "locus\ttranscriptId\tcoverage" << endl;
	outputfile.close();
	for (chrLoopCnt = 0; chrLoopCnt < chrNum; ++chrLoopCnt)
	{
		sprintf(comd, "./process %sGTF/%s/ %sresult/%s/ %s", argv[4], chrName[chrLoopCnt], argv[4], chrName[chrLoopCnt], outputfilename);
		i = system(comd);
	}

	// Clean temporary files
	sprintf(comd, "rm -r %sGTF", argv[4]);
	i = system(comd);
	sprintf(comd, "rm -r %sSAM", argv[4]);
	i = system(comd);
	sprintf(comd, "rm -r %sresult", argv[4]);
	i = system(comd);

	return 0;
}

void inputChrName(char *namefile)
{
	ifstream chrFile;
	string info;
	char filename[500];
	sprintf(filename, "%sChromosomeName.txt", namefile);
	chrFile.open(filename);

	char tmp[100];
	for (int i = 0; i < 100; i++)
	{
		tmp[i] = '\0';
	}

	chrFile >> tmp;
	while (tmp[0] != '\0')
	{
		getline(chrFile, info);

		if (tmp[0] == 'c' && tmp[1] == 'h' && tmp[2] == 'r' && tmp[3] != 'M' && tmp[6] == '\0')
		{
			strcpy(chrName[chrNum], tmp);
			chrNum++;
		}
// 		strcpy(chrName[chrNum], tmp);
// 		chrNum++;

		for (int i = 0; i < 100; i++)
		{
			tmp[i] = '\0';
		}
		chrFile >> tmp;		
	}
	chrFile.close();

	return;
}
